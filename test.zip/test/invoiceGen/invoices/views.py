from rest_framework import viewsets,status,views
from rest_framework.response import Response
from .models import Invoices,Items,BillSundry
from .serializers import InvoiceSerializer, InvoiceItemSerializer,BillSundrySerializer

class InvoiceViewSet(viewsets.ModelViewSet):
    queryset=Invoices.objects.all()
    serializer_class=InvoiceSerializer

def addItems(itemslist):
    total=0
    for item in itemslist:
        serializer=InvoiceItemSerializer(data=item)
        try:
            if serializer.is_valid():
                serializer.save()
                total+=serializer.data['Amount']
        except:
            return Response(serializer.errors,status.HTTP_400_BAD_request)
    return total
def addBillSundry(itemslist):
    totalbillsundry=0
    for item in itemslist:
        serializer=BillSundrySerializer(data=item)
        try:
            if serializer.is_valid():
                totalbillsundry+=serializer.data['Amount']
                serializer.save()
        except:
            return Response(serializer.errors,status.HTTP_400_BAD_request)
    return totalbillsundry
class AddInvoice(views.APIView):
    def post(self,request):
        data=request.data
        total_amount=addItems(request.data.items)
        total_billsundry=addBillSundry(request.data.BillSundry)
        request.data['total_amount']=total_amount
        request.data['total_billsundry']=total_billsundry
        serializer=InvoiceSerializer(request.data)#,'total_amount'=total_amount,'total_billsundry':total_billsundry)
        if serializer.isvalid():
            serializer.save()
            return Response(status=status.HTTP_201_CREATED)
    