from django.db import models

class Invoices(models.Model):
    Date=models.DateField()
    InvoiceNumber=models.AutoField()
    CustomerName=models.CharField(max_length=25)
    BillingAddress=models.TextField(max_length=255)
    ShippingAddress=models.TextField(max_length=255)
    GSTIN=models.CharField(max_length=25)
    TotalAmount=models.DecimalField()


class Items(models.Model):
    itemName=models.CharField(max_length=24)
    quantity=models.DecimalField()
    price=models.DecimalField()
    Amount=models.DecimalField()
    invoice=models.ForeignKey(Invoices,on_delete=models.CASCADE,related_name='item')


class BillSundry(models.Model):
    BillSundryName=models.CharField(max_length=25)
    amount=models.DecimalField()
    invoice=models.ForeignKey(Invoices,on_delete=models.CASCADE,related_name='bill_sundry')


