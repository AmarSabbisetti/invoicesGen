from rest_framework import serializers
from .models import Invoices,Items,BillSundry

class InvoiceItemSerializer(serializers.ModelSerializer):
    class Meta:
        model=Items
        fields=['Name','quantity','price','amount']
    
    def validate(self,data):
        quantity=data.get('quantity')
        price=data.get('price')
        amount=data.get('amount')
        if quantity is None and quantity<0:
            raise serializers.ValidationError('invalid quantity') 
        if price is None or price<0 :
            raise serializers.ValidationError('invalid price')
        if amount is None and amount!=quantity*price:
            raise serializers.ValidationError('Amount and quantity * price are not equal')

class BillSundrySerializer(serializers.ModelSerializer):
    class Meta:
        model=BillSundry
        fields='__all__'

class InvoiceSerializer(serializers.ModelSerializer):
    items=InvoiceItemSerializer(many=True)
    bill_sundry=BillSundrySerializer(many=True)

    class Meta:
        model=Invoices 
        fields=['InvoiceNumber','items','bill_sundry','TotalAmount','BillingAddress']
    
    def validate(self,**data):
        total_items_amount=data.get('total_amount')
        total_billsundry_amount=data.get('total_billsundry')
        TotalAmount=data.get('TotalAmount')
        if TotalAmount is not None:
            if TotalAmount!=total_items_amount+total_billsundry_amount:
                raise serializers.ValidationError("Total is not matching")
        else: raise serializers.ValidationError("Invalide Total Amount")